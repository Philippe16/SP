### Table Football Tournament - SP3

Automatic system to manage a tournament based around table football

Created by:

[Philippe](https://github.com/Philippe16)

[Christian J.](https://github.com/Tsukani)

[Viktor](https://github.com/viggo23111)

[Aleksander W.](https://github.com/LaDane)